<?php
$TOS_USER = trim(shell_exec('id -un'));
if  (!((isset($_COOKIE['userName']) && ($_COOKIE['userName'] == $TOS_USER)) && 
	   (isset($_COOKIE['loginStatus']) &&  ($_COOKIE['loginStatus'] == "true" ))))
{
    $json = new Services_JSON();
    echo $json->encode(array("error" => true, "message" => "(Access denied !) - you need to login on TOS with an admin role account"));}
?>