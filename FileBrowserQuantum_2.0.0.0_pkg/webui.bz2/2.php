<?php

/**
 * Main of the module
 *
 *
 */

// tag file for includes
define('VALID_MODULE', TRUE);

// some constants used here and in included files

// helper to strip slashes on input
$request = ModuleUtilities::StripSlashesDeep($_REQUEST);

// how we got called
$script_url     = $_SERVER["PHP_SELF"];
$script_url_mod = $script_url . "?Module=" . urlencode($request["Module"]);

// access control - limit acces to the admin account
include 'session_info.php';
?>

<!-- MODULE STYLES -->

<link   type="text/css" href="css/terra/jquery-ui-1.8.16.custom.css" rel="stylesheet"/>
<style type="text/css">
    div.module               { font-family: verdana,arial,helvetica; font-size: x-small; }
    div.title                { color: maroon; font-weight: bolder; font-size: medium; 
                               padding: 3px 10px 3px 10px; border-bottom: 1px solid maroon;
                               background-color: #f0f0f0;
                             }
    div.block                { padding: 3px 10px 3px 10px; border-bottom: 1px solid maroon; }
    .moduleinfo              { text-align: justify; padding: 0px 5px 0px 5px; }
    form                     { margin: 0; padding: 0; }
    table.outer              { border: 0; border-collapse: collapse; empty-cells: show; }
    table.outer td           { vertical-align: top; padding: 0; }
    table.module             { border: 1px solid maroon; border-collapse: collapse; empty-cells: show; }
    table.module td          { padding: 1px 5px 1px 5px; font-size: small; }
    table.module td.title    { font-weight: bolder; white-space: nowrap; }
    table.module td.pardesc  { font-size: x-small; font-style: italic; padding-left: 20px; }
    table.module tr.bline td { border-bottom: 1px solid maroon; }
    table.module tr.tline td { border-top: 1px solid maroon; }
    table.module tr.title td { background-color: #f0f0f0; color: maroon; }
    table.form td            { vertical-align: middle; }
    table.form td.error      { color: red; padding: 0px 10px 0px 10px; }
    div.moduleinfo           { text-align: justify; padding: 5px 10px 5px 10px; font-size: x-small; }
    .stopped                 { color: red; }
    .running                 { color: darkgreen; }
    .error                   { color: red; }
    .red                     { color: red; }

    /* hide the close x on the loading screen */
    .loadingScreenWindow .ui-dialog-titlebar-close {
	    display: none;
    }
    
    /* hide the close x on the confirmation dialof */
    .confirmDialogWindow .ui-dialog-titlebar-close {
	    display: none;
    }

    textarea.code    { font-family: 'Courier New', Courier, monospace; font-size: small; }

    input[type=text][readonly] {
        color: maroon;
    }
</style>

<!-- Javascript -->

<script type="text/javascript" src="js/jquery-1.6.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.16.custom.min.js"></script>
<script type="text/javascript" src="js/ui.js"></script>

<!-- CONFIGURATION -->
</br>
<div id="config_areas" align="center" style="min-width:600px;">

    <h3><a href="#">Edit filebrowser.yml</a></h3>
    <div style="padding:0px;">
        <div style="padding:0px;">
            <textarea id="adv_config_text" style="width:800px;height:200px;" class="code adv_config" cols="80" wrap="off"></textarea>
        </div>
        <div style="text-align:center;">
            <button id="btn_adv_save" class="adv_config">Apply</button>
        </div>
    </div>
<!--
    <h3><a href="#">Edit http port</a></h3>
    <div style="padding:0px;">
        <div style="padding:0px;">
            <textarea id="adv_config_text1" style="width:800px;height:200px;" class="code adv_config1" cols="80" wrap="off"></textarea>
        </div>
        <div style="text-align:center;">
            <button id="btn_adv_save1" class="adv_config1">Apply</button>
        </div>
    </div>
	
	<h3><a href="#">Edit https port</a></h3>
    <div style="padding:0px;">
        <div style="padding:0px;">
            <textarea id="adv_config_text2" style="width:800px;height:200px;" class="code adv_config2" cols="80" wrap="off"></textarea>
        </div>
        <div style="text-align:center;">
            <button id="btn_adv_save2" class="adv_config2">Apply</button>
        </div>
    </div>
	
		<h3><a href="#">Edit /etc/hosts</a></h3>
    <div style="padding:0px;">
        <div style="padding:0px;">
            <textarea id="adv_config_text3" style="width:800px;height:200px;" class="code adv_config3" cols="80" wrap="off"></textarea>
        </div>
        <div style="text-align:center;">
            <button id="btn_adv_save3" class="adv_config3">Apply</button>
        </div>
    </div>
	
-->
	
</div>


<?php

/** Functions **/

// autoload class definitions
function __autoload($class_name)
{
    @include_once("lib/" . $class_name . ".class.php");
}

?>
