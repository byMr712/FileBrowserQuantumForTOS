<?php
// tag file for includes
define('VALID_MODULE', TRUE);

// some constants used here and in included files
define('MODULE_NAME', 'FileBrowserQuantum');

include('/usr/local/' . MODULE_NAME . '/bin/config.inc.php');

// access control - limit acces to the admin accounts
include 'session_info.php';
?>
<?php
  // On définit le tableau contenant les pages autorisées
  // ----------------------------------------------------
 $pageOK = array(
	'1' => array('titre' => 'About FileBrowserQuantum', 'script' => '1.php'),
	'2' => array('titre' => 'Edit config File', 'script' => '2.php'),
	'6' => array('titre' => 'View log', 'script' => '6.php'),
	'7' => array('titre' => 'View log', 'script' => '7.php'),
	'8' => array('titre' => 'View log', 'script' => '8.php'),
	'12' => array('titre' => 'Stopping...', 'script' => '12.php'),
	'13' => array('titre' => 'Starting...', 'script' => '13.php'),
	'14' => array('titre' => 'Starting...', 'script' => '14.php'),
	'17' => array('titre' => 'Restarting...', 'script' => '17.php'),
	'18' => array('titre' => 'Force close...', 'script' => '18.php'),
	);

  // On teste que le paramètre d'url existe et qu'il est bien autorisé
  // -----------------------------------------------------------------
  if ( (isset($_GET['page'])) && (isset($pageOK[$_GET['page']])) ) {
   $page = $_GET['page'];   
  } else {
   $page = '1';
  }
// Chargement des infos de la $page
$title = $pageOK[$page]['titre'];
$script = $pageOK[$page]['script'];
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title; ?></title>
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
<style type="text/css">
<!--
body {
	background-color: #D9E8FB;
}
-->
</style></head>
<body>
<div id="top">
<?php include('top.php');?>
</div>
<div id="main">
<?php include $script;?>
</div>
<div id="foot">
<?php include('foot.php');?>
</div>


</body>
</html>
