<?php
// tag file for includes
define('VALID_MODULE', TRUE);
// access control - limit acces to the admin account
include 'session_info.php';
?>
<style type="text/css">
<!--
#forumlaire {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	color: #000;
	text-decoration: none;
	text-align: left;
	background-color: #D9E8FB;
}
input {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	color: #333;
	text-decoration: none;
}
#process {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	font-weight: lighter;
	font-variant: normal;
	text-transform: none;
	color: #C60;
	text-decoration: none;
	text-align: center;
}
#menu_proc {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 10px;
	font-style: normal;
	line-height: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	color: #000;
	text-decoration: none;
	text-align: center;
}
#menu_proc2 {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 10px;
	font-style: normal;
	line-height: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	color: #000;
	text-decoration: none;
	text-align: center;
}

#table {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	font-weight: lighter;
	font-variant: normal;
	text-transform: none;
	color: #000;
	text-decoration: none;
	border: 1px dashed #C60;
	background-color: #D9E8FB;
}
-->
</style>
<div id="forumlaire">
<table width="60%" border="0" align="center" cellpadding="1" cellspacing="1" id="process">
  <tr>
    <td id="menu_proc">
      <p><a href="https://filebrowserquantum.com/en/" target="_blank" style="color: #CC0000">FileBrowser Quantum Webpage</a></br>
	  

<?php

$port = "8087";
echo "<p>Click for <a href=http://".$_SERVER['SERVER_ADDR'].":".$port." div style='color: #CC0000' target='blank'>Web Interface</a></div> to access complete HTTP Web Interface 
    (:".$port.")</p>";
?>


   </td>
  </tr>
</table>
</div>
<br />
<div id="forumlaire">
  <table width="60%" border="0" align="center" cellpadding="1" cellspacing="1" id="table">
    <tr>
    <td id="menu_proc"><p>The best free self-hosted web-based file manager with source configuration, modern authentication, office support, and lightning-fast search. <b><?php echo "$SUPERUSER/MOD_CONFIG/FileBrowserQuantum"; ?></b></p>
	  </p>
	  <p><a href="https://tmnascommunity.eu/download/FileBrowserQuantum/" target="_blank" style="color: #CC0000">FileBrowser Quantum TMNASCommunity</a></br>
     </td>
  </tr>
  </table>
</div>