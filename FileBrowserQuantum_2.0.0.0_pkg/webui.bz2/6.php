<?php
// tag file for includes
define('VALID_MODULE', TRUE);
// access control - limit acces to the admin account

include 'session_info.php';
?>
<style type="text/css">
<!--
#forumlaire {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	color: #000;
	text-decoration: none;
	text-align: center;
	background-color: #D9E8FB;
}
input {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	color: #333;
	text-decoration: none;
}
#process {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	font-weight: lighter;
	font-variant: normal;
	text-transform: none;
	color: #C60;
	text-decoration: none;
	text-align: center;
}
#menu_proc {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 10px;
	font-style: normal;
	line-height: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	color: #C00;
	text-decoration: none;
	text-align: center;
}
#table {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	font-weight: lighter;
	font-variant: normal;
	text-transform: none;
	color: #000;
	text-decoration: none;
	border: 1px dashed #C60;
	background-color: #FFF;
}
body {
	background-color: #D9E8FB;
}
-->
</style>
<div id="forumlaire">
  <p>&nbsp;</p>
  <p> FileBrowserQuantum.log </p>
  <p>
    <textarea name="" cols="120" rows="50">
<?php
/*Ouverture du fichier en lecture seule*/
$handle = fopen('/usr/local/FileBrowserQuantum/config/filebrowser.log', 'r');
/*Si on a réussi à ouvrir le fichier*/
if ($handle)
{
        /*Tant que l'on est pas à la fin du fichier*/
       while (!feof($handle))
      {
           /*On lit la ligne courante*/
                $buffer = fgets($handle);
           /*On l'affiche*/
            echo $buffer;
       }
   /*On ferme le fichier*/
     fclose($handle);
}
?>

    </textarea>
  </p>
</div>