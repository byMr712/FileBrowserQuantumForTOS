<?php

/**
 * Ajax handler of the module
 *
 *
 */

// tag file for includes
define('VALID_MODULE', TRUE);

//module name
define('MODULE_NAME', 'FileBrowserQuantum');

// some constants used here and in included files
define('RC_SCRIPT'  , '/etc/init.d/' . MODULE_NAME . '');
define('CFG_FILE'   , '/usr/local/FileBrowserQuantum/config/filebrowser.yml');
/*
define('CFG_FILE1'   , '/Volume1/MOD_CONFIG/SAB3/httpport');
define('CFG_FILE2'   , '/Volume1/MOD_CONFIG/SAB3/httpsport');
define('CFG_FILE3'   , '/raid/data/module/' . MODULE_NAME . '');
*/
session_start();

// helper to strip slashes on input
$request = ModuleUtilities::StripSlashesDeep($_REQUEST);

/** load JSON */
require_once("../lib/JSON.php");

include 'session_info_ax.php';

/** get function to execute */
$function = 'ax_handle_' . $request['action'];

if ( @function_exists($function) ) {
    $ret = @call_user_func($function, $request);
    $json = new Services_JSON();
    echo $json->encode($ret);
}
else {
    $json = new Services_JSON();
    echo $json->encode(array("error" => true, "message" => "Invalid action: '" . $request['action'] . "'."));
}

/** 
 * autoload class definitions
 *
 */
function __autoload($class_name)
{
    @include_once("../lib/" . $class_name . ".class.php");
}

/**
 * Return the configuration.
 *
 */
function ax_handle_getConfig($r)
{
    $result = array("config" => null, "error" => true, "message" => null );

    $file = @file(CFG_FILE);

    if ( FALSE === $file ) 
    {
        $result["message"] = "Unable to load config file";
        return $result;
    }
    
    $result["config"]   = implode("\n", array_map('rtrim', $file)) . "\n";
    $result["error"]    = false;
    
    return $result;
}

/**
 * Return the configuration.
 *
 */
function ax_handle_getConfig1($r)
{
    $result = array("config" => null, "error" => true, "message" => null );

    $file = @file(CFG_FILE1);

    if ( FALSE === $file ) 
    {
        $result["message"] = "Unable to load config file";
        return $result;
    }
    
    $result["config"]   = implode("\n", array_map('rtrim', $file)) . "\n";
    $result["error"]    = false;
    
    return $result;
}

/**
 * Return the configuration.
 *
 */
function ax_handle_getConfig2($r)
{
    $result = array("config" => null, "error" => true, "message" => null );

    $file = @file(CFG_FILE2);

    if ( FALSE === $file ) 
    {
        $result["message"] = "Unable to load config file";
        return $result;
    }
    
    $result["config"]   = implode("\n", array_map('rtrim', $file)) . "\n";
    $result["error"]    = false;
    
    return $result;
}

/**
 * Return the configuration.
 *
 */
function ax_handle_getConfig3($r)
{
    $result = array("config" => null, "error" => true, "message" => null );

    $file = @file(CFG_FILE3);

    if ( FALSE === $file ) 
    {
        $result["message"] = "Unable to load config file";
        return $result;
    }
    
    $result["config"]   = implode("\n", array_map('rtrim', $file)) . "\n";
    $result["error"]    = false;
    
    return $result;
}

/**
 * Apply a new configuration.
 *
 */
function ax_handle_setConfig($r)
{
    $result = array("config" => null, "error" => true, "message" => null );
    
    if ( ! isset($r['config']) )
    {
        $result["message"] = "No config to apply";
        return $result;
    }
    
    $file = @file(CFG_FILE);
    
    if ( FALSE === $file )
    {
        $result["message"] = "Unable to open config file";
        return $result;
    }

    $oconfig   = implode("\n", array_map('rtrim', $file)) . "\n";

    if ( FALSE === @file_put_contents(CFG_FILE, $r['config']) )
    {
        $result["config"]  = $oconfig;
        $result["message"] = "Failed to save config";
        return $result;
    }

    $result["error"]   = false;
    $result["config"]  = $r["config"];

    $out = array();
    $ret = -1;
    $cmd = 'systemctl reload '. MODULE_NAME;
    
    exec($cmd, $out, $ret);

    if ( $ret != 0 ) {
        $result["error"]   = true;
        $result["message"] = "<b>Failed to reload daemon:</b><br/>\n" . implode("<br/>\n", array_map("htmlentities", $out));
    }

    return $result;
	
}

/**
 * Apply a new configuration.
 *
 */
function ax_handle_setConfig1($r)
{
    $result = array("config" => null, "error" => true, "message" => null );
    
    if ( ! isset($r['config']) )
    {
        $result["message"] = "No config to apply";
        return $result;
    }
    
    $file = @file(CFG_FILE1);
    
    if ( FALSE === $file )
    {
        $result["message"] = "Unable to open config file";
        return $result;
    }

    $oconfig   = implode("\n", array_map('rtrim', $file)) . "\n";

    if ( FALSE === @file_put_contents(CFG_FILE1, $r['config']) )
    {
        $result["config"]  = $oconfig;
        $result["message"] = "Failed to save config";
        return $result;
    }

    $result["error"]   = false;
    $result["config"]  = $r["config"];

    $out = array();
    $ret = -1;
    $cmd = 'systemctl reload '. MODULE_NAME;
    
    exec($cmd, $out, $ret);

    if ( $ret != 0 ) {
        $result["error"]   = true;
        $result["message"] = "<b>Failed to reload daemon:</b><br/>\n" . implode("<br/>\n", array_map("htmlentities", $out));
    }

    return $result;
}

/**
 * Apply a new configuration.
 *
 */
function ax_handle_setConfig2($r)
{
    $result = array("config" => null, "error" => true, "message" => null );
    
    if ( ! isset($r['config']) )
    {
        $result["message"] = "No config to apply";
        return $result;
    }
    
    $file = @file(CFG_FILE2);
    
    if ( FALSE === $file )
    {
        $result["message"] = "Unable to open config file";
        return $result;
    }

    $oconfig   = implode("\n", array_map('rtrim', $file)) . "\n";

    if ( FALSE === @file_put_contents(CFG_FILE2, $r['config']) )
    {
        $result["config"]  = $oconfig;
        $result["message"] = "Failed to save config";
        return $result;
    }

    $result["error"]   = false;
    $result["config"]  = $r["config"];

    $out = array();
    $ret = -1;
    $cmd = 'systemctl reload '. MODULE_NAME;
    
    exec($cmd, $out, $ret);

    if ( $ret != 0 ) {
        $result["error"]   = true;
        $result["message"] = "<b>Failed to reload daemon:</b><br/>\n" . implode("<br/>\n", array_map("htmlentities", $out));
    }

    return $result;
}

/**
 * Apply a new configuration.
 *
 */
function ax_handle_setConfig3($r)
{
    $result = array("config" => null, "error" => true, "message" => null );
    
    if ( ! isset($r['config']) )
    {
        $result["message"] = "No config to apply";
        return $result;
    }
    
    $file = @file(CFG_FILE3);
    
    if ( FALSE === $file )
    {
        $result["message"] = "Unable to open config file";
        return $result;
    }

    $oconfig   = implode("\n", array_map('rtrim', $file)) . "\n";

    if ( FALSE === @file_put_contents(CFG_FILE3, $r['config']) )
    {
        $result["config"]  = $oconfig;
        $result["message"] = "Failed to save config";
        return $result;
    }

    $result["error"]   = false;
    $result["config"]  = $r["config"];

    $out = array();
    $ret = -1;
    $cmd = 'systemctl reload '. MODULE_NAME;
    
    exec($cmd, $out, $ret);

    if ( $ret != 0 ) {
        $result["error"]   = true;
        $result["message"] = "<b>Failed to reload daemon:</b><br/>\n" . implode("<br/>\n", array_map("htmlentities", $out));
    }

    return $result;
}
?>
