<?php
$TOS_USER = trim(shell_exec('id -un'));
if  (!((isset($_COOKIE['userName']) && ($_COOKIE['userName'] == $TOS_USER)) && 
	   (isset($_COOKIE['loginStatus']) &&  ($_COOKIE['loginStatus'] == "true" ))))
{

 die('<br><br><center><font color="red" size="4"> "(Access denied !) - you need to login on TOS with the superuser role account created during TOS setup" </font></center>');
}
?>