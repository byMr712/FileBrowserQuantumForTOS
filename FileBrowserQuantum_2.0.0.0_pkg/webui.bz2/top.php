<?php
// tag file for includes
define('VALID_MODULE', TRUE);
// access control - limit acces to the admin account
include 'session_info.php';
?>


<link rel="stylesheet" href="mbcsmbmcp.css" type="text/css" />
<style>
<!--

#tabledepapp {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	font-weight: lighter;
	font-variant: normal;
	text-transform: none;
	color: #000;
	text-decoration: none;
	background-color: #D9E8FB;
}

#menu_proc2depapp {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 10px;
	font-style: normal;
	line-height: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	color: red;
	text-decoration: none;
	text-align: center;
	background-color:white;
}

#mbmcpebul_wrapper {
  padding: 0;
  border-style: solid;
  border-color: #000000;
  border-width: 0;
  border-radius: 0;
  background-color: #000000;
  box-shadow: none;
  border-collapse: separate;
  font-size: 0;
  line-height: 0;
}

#mbmcpebul_wrapper.quirks #mbmcpebul_table ul li {
  width: 100%;
}

#mbmcpebul_table {
  margin: 0px;
  margin-bottom: -1px;
  margin-right: -1px;
  padding: 0;
  line-height: 0px;
  font-size: 0px;
  display: inline-block;
  width: auto;
}

#mbmcpebul_table li {
  list-style: none;
  float: left;
  margin: 0px 1px 1px 0px;
  padding: 0;
  float: left;
  display: inline-block;
}

#logo img {
	text-align: center;
}
-->

</style>

<div id=logo align="center"><img src="FileBrowserQuantum.webp" width="245" height="125" alt="" /><br />
</div>
<!-- Menus created with the trial version of Easy Button & Menu Maker can be used for evaluation purposes only.
     Using this code (whether modified or not) on an actual website without having paid for the software is a
     serious violation of copyright laws. -->
<div id=menu_top align="center">
 <div id="mbmcpebul_wrapper">
  <ul id="mbmcpebul_table" class="mbmcpebul_menulist css_menu">
  <li><div class="buttonbg gradient_button gradient27" style="width: 64px;"><a href="?page=1" class="button_1">Home</a></div></li>
  <li><div class="buttonbg gradient_button gradient27" style="width: 150px;"><a href="?page=2" class="button_1">Configuration Files</a></div></li>
  <li><div class="buttonbg gradient_button gradient27" style="width: 95px;"><div class="arrow"><a>Log Files</a></div></div>
    <ul class="gradient_menu gradient33">
    <li class="gradient_menuitem gradient31 first_item"><a href="?page=6" title="">filebrowser.log</a></li>
	<li class="gradient_menuitem gradient31 last_item"><a href="?page=8" title="">start_log</a></li>
    </ul></li>
  <li><div class="buttonbg gradient_button gradient27" style="width: 152px;"><div class="arrow"><a>Application Control</a></div></div>
    <ul class="gradient_menu gradient95">
    <li class="gradient_menuitem gradient31 first_item"><a href="?page=12" title="">Stop App</a></li>
    <li class="gradient_menuitem gradient31"><a href="?page=13" title="">Start App</a></li>
	<li class="gradient_menuitem gradient31"><a href="?page=14" title="">Remove Config</a></li>
	<li class="gradient_menuitem gradient31"><a href="?page=17" title="">Restart App</a></li>
	<li class="gradient_menuitem gradient31 last_item"><a href="?page=18" title="">Force Stop App</a></li>
    </ul></li>
  </ul>
 </div>
</div>
<!-- Menus will work without this javascript file. It is used only for extra
     effects, improved usability, compatibility with very old web browsers
     and support for touch screen devices. -->
<script type="text/javascript" src="mbjsmbmcp.js"></script>
<div align="center"
<?php
$output = shell_exec('/etc/init.d/' . MODULE_NAME . ' status');
echo "<pre>$output</pre>";
?>
</div>
<script type="text/javascript" src="mbjsmbmcp.js"></script>


<div align="center"
<?php
$output = shell_exec('/etc/init.d/' . MODULE_NAME . ' inst_version');
echo "<pre>$output</pre>";
?>
</div>

<div align="center id="formulaire">
  <table width="60%" border="0" align="center" cellpadding="1" cellspacing="1" id="tabledepapp">
    <tr>
      <td id="menu_proc2depapp">
<?php
$output = shell_exec('/etc/init.d/' . MODULE_NAME . ' dep_check');
echo "$output";
?>
      </td>
    </tr>
  </table>
  </form>
</div>
