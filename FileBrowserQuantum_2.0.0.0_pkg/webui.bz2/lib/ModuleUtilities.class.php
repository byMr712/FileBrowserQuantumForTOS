<?php

if ( ! defined('VALID_MODULE') ) { die("(no access)"); }

/**
 * Module Utilities
 *
 */
class ModuleUtilities
{
    /** Check if a process is running.
     *
     * @param pattern Perl regex pattern
     * @return TRUE if patern found in process table, else FALSE
     */
    public static function ProcessRunning($pattern)
    {
        $result = FALSE;

        $ph = popen('/bin/ps', 'r');
        if ( $ph )
        {
            $pattern = '@\s' . $pattern . '@';
            while ( ($line = fgets($ph)) !== FALSE )
            {
                if ( preg_match($pattern, $line) )
                {
                    $result = TRUE;
                    break;
                }
            }
            pclose($ph);
        }

        return $result;
    }
    
    /** Strip slashes if magic quotes is active
     *
     */
    public static function StripSlashesDeep($value)
    {
        return __ModuleUtilities_StripSlashesDeep($value);
    }
    
    /** Return the FW version
     *
     */
    public static function GetFirmwareVersion()
    {
        return @preg_replace('/^([\d\.]+).*/', '$1', @file_get_contents("/img/version"));
    }
}

/** Helper to be able to use array_map
 *
 */
function __ModuleUtilities_StripSlashesDeep($value)
{
    if ( get_magic_quotes_gpc() )
    {
        if ( is_array($value) )
            $value = array_map('__ModuleUtilities_StripSlashesDeep', $value);
        else
            $value = stripslashes($value);
    }
    
    return $value;
}

?>