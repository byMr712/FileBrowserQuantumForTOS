<?php
// tag file for includes
define('VALID_MODULE', TRUE);
// access control - limit acces to the admin account
include 'session_info.php';
?>
<style type="text/css">
<!--
#foot {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	text-decoration: none;
	text-align: center;
	background-attachment: inherit;
	background-image: url(img/foot.JPG);
	background-repeat: repeat-x;
	height: 38px;
	color: #FFF;
	background-color: #000;
}
a:hover {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	color: #FF0;
	text-decoration: none;
}
a:visited {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	color: #FFF;
	text-decoration: none;
}
a:link {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	color: #FFF;
	text-decoration: none;
}
a:active {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	color: #FF0;
	text-decoration: none;
}
-->
</style>
<div id="foot">
<p>Copyright <a href="https://tmnascommunity.eu" target="_blank" style="color: #FF8C00">tmnascommunity.eu</a> - Module made by OutkastM - if you like my modules you can support me <br />
  Your donations are really appreciated. </p>
<a href="https://www.paypal.com/donate/?hosted_button_id=M9EUGXTPQRXXG" target="_blank" rel="nofollow noopener"><img src="img/paypa-donate2.png" alt="Click to Donate"></a>
</form>
</div>

