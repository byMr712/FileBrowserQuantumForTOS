<?php
// tag file for includes
define('VALID_MODULE', TRUE);
// access control - limit acces to the admin account
include 'session_info.php';
?>
<div align="center"
<?php
$output = shell_exec('systemctl reload ' . MODULE_NAME . '');
echo "<pre>$output</pre>";
?>
</div>

<script>
//Using setTimeout to execute a function after 5 seconds.

setTimeout(function () {
   //Redirect with JavaScript
   window.location.href= 'index.php?page=1';
}, 2000);
</script>
