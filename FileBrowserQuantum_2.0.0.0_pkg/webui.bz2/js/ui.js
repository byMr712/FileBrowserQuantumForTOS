
/*
 * Global variables
 */
 
MODULE_WWW  = "/FileBrowserQuantum";
AX_HANDLER  = "/FileBrowserQuantum/ax/handler.php";


/**
 * set the service status and version
 *
 */
function updateStatus()
{
    updateStatusL(false);
}


/**
 * set the service status and version
 *
 */
function updateStatusL(loop)
{
    $.getJSON(
        AX_HANDLER, 
        { action: "getStatus" },
        function(data)
        {
            if ( data.status != $("#crond_status_text").text() )
            {
                $("#crond_status_text").removeClass("running stopped").addClass(data.status).text(data.status);
            }
            
            if ( loop ) {
                setTimeout(updateStatus, 5000);
            }
        }
    );
}


/**
 *
 *
 */
function loadConfig()
{
    $(".adv_config").attr("disabled",true);    
    $("#adv_config_text").val("");
    
    $.getJSON(
        AX_HANDLER, 
        { action: "getConfig" },
        function(data)
        {
            if ( ! data.error )
            {
                $("#adv_config_text").val(data.config);
                $(".adv_config").attr("disabled",false);    
            }
        }
    );
} 

/**
 *
 *
 */
function loadConfig1()
{
    $(".adv_config1").attr("disabled",true);    
    $("#adv_config_text1").val("");
    
    $.getJSON(
        AX_HANDLER, 
        { action: "getConfig1" },
        function(data)
        {
            if ( ! data.error )
            {
                $("#adv_config_text1").val(data.config);
                $(".adv_config1").attr("disabled",false);    
            }
        }
    );
}

/**
 *
 *
 */
function loadConfig2()
{
    $(".adv_config2").attr("disabled",true);    
    $("#adv_config_text2").val("");
    
    $.getJSON(
        AX_HANDLER, 
        { action: "getConfig2" },
        function(data)
        {
            if ( ! data.error )
            {
                $("#adv_config_text2").val(data.config);
                $(".adv_config2").attr("disabled",false);    
            }
        }
    );
} 

/**
 *
 *
 */
function loadConfig3()
{
    $(".adv_config3").attr("disabled",true);    
    $("#adv_config_text3").val("");
    
    $.getJSON(
        AX_HANDLER, 
        { action: "getConfig3" },
        function(data)
        {
            if ( ! data.error )
            {
                $("#adv_config_text3").val(data.config);
                $(".adv_config3").attr("disabled",false);    
            }
        }
    );
} 

/**
 *
 *
 */
function applyConfig()
{
    $(".adv_config").attr("disabled",true);    

    waitingDialog({title: "Please wait ...", message: "Saving config"});

    $.post(
        AX_HANDLER, 
        { action: "setConfig", config: $("#adv_config_text").val() },
        function(data)
        {
            if ( data.error )
            {
                $("#errorDialog").html(data.message).dialog("open");
            }
            else
            {
                $("#adv_config_text").val(data.config);
            }
            $(".adv_config").attr("disabled",false);
            updateStatus();
        },
        'json'
    );

    $("#loadingDialog").ajaxStop(closeWaitingDialog);
}

/**
 *
 *
 */
function applyConfig1()
{
    $(".adv_config1").attr("disabled",true);    

    waitingDialog({title: "Please wait ...", message: "Saving http port"});

    $.post(
        AX_HANDLER, 
        { action: "setConfig1", config: $("#adv_config_text1").val() },
        function(data)
        {
            if ( data.error )
            {
                $("#errorDialog").html(data.message).dialog("open");
            }
            else
            {
                $("#adv_config_text1").val(data.config);
            }
            $(".adv_config1").attr("disabled",false);
            updateStatus();
        },
        'json'
    );

    $("#loadingDialog").ajaxStop(closeWaitingDialog);
}

/**
 *
 *
 */
function applyConfig2()
{
    $(".adv_config2").attr("disabled",true);    

    waitingDialog({title: "Please wait ...", message: "Saving https port"});

    $.post(
        AX_HANDLER, 
        { action: "setConfig2", config: $("#adv_config_text2").val() },
        function(data)
        {
            if ( data.error )
            {
                $("#errorDialog").html(data.message).dialog("open");
            }
            else
            {
                $("#adv_config_text2").val(data.config);
            }
            $(".adv_config2").attr("disabled",false);
            updateStatus();
        },
        'json'
    );

    $("#loadingDialog").ajaxStop(closeWaitingDialog);
}

/**
 *
 *
 */
function applyConfig3()
{
    $(".adv_config3").attr("disabled",true);    

    waitingDialog({title: "Please wait ...", message: "Saving https.conf"});

    $.post(
        AX_HANDLER, 
        { action: "setConfig3", config: $("#adv_config_text3").val() },
        function(data)
        {
            if ( data.error )
            {
                $("#errorDialog").html(data.message).dialog("open");
            }
            else
            {
                $("#adv_config_text3").val(data.config);
            }
            $(".adv_config3").attr("disabled",false);
            updateStatus();
        },
        'json'
    );

    $("#loadingDialog").ajaxStop(closeWaitingDialog);
}

/**
 *
 *
 */
function waitingDialog(waiting)
{
    img = "<img src='" + MODULE_WWW + "/img/ajax-loader.gif' alt='Loading ...' style='vertical-align:middle;margin-right:5px;width:1em;height:1em;' />";
	$("#loadingDialog")
	    .html(waiting.message && '' != waiting.message ? waiting.message : 'Please wait...')
	    .dialog('option', 'title', img + (waiting.title && '' != waiting.title ? waiting.title : 'Loading'))
	    .dialog('open');
}


/**
 *
 *
 */
function closeWaitingDialog()
{
	$("#loadingDialog").dialog('close');
}


/**
 *
 *
 */
function confirmAction(title, msg, ok)
{
    // confirmation dialog
    $("<div id='confirmDialog'></div>")
        .html(msg)
        .dialog({
            autoOpen: true,
            dialogClass: 'confirmDialogWindow',
            title: title,
            modal: true,
            width: 400,
            buttons: { 
                "Ok": function() { ok(); $(this).dialog("destroy"); },
                "Cancel": function() { $(this).dialog("destroy"); },
            }
        }); // end of confirmDialog
}
 
/**
 *
 *
 */
$(document).ready(function()
{
    // "Loading..." dialog
	$("<div id='loadingDialog'></div>")
	    .dialog({
            autoOpen: false,
            dialogClass: "loadingScreenWindow",
            closeOnEscape: false,
            draggable: false,
            width: 460,
            minHeight: 50,
            modal: true,
            buttons: {},
            resizable: false
        }); // end of loadingDialog

    waitingDialog({});

    // error dialog
    $("<div id='errorDialog'></div>")
        .dialog({
            autoOpen: false,
            dialogClass: 'errorDialogWindow',
            title: 'Error',
            modal: true,
            width: 400,
            buttons: { "Ok": function() { $(this).dialog("close"); } }
        }); // end of errorDialog

    // make buttons to jQueryUI buttons
    $("button").button();
    
    $("#config_areas").accordion({
        collapsible: true,
        active: false,
        header: "h3",
        autoHeight: false
    });

    // add resize handles to the textarea
    $("#adv_config_text").resizable({ handles: "se" });

    // add handler for the click event on the apply button
    $("#btn_adv_save").click(applyConfig);
	
	    // add resize handles to the textarea
    $("#adv_config_text1").resizable({ handles: "se" });

    // add handler for the click event on the apply button
    $("#btn_adv_save1").click(applyConfig1);
	
		    // add resize handles to the textarea
    $("#adv_config_text2").resizable({ handles: "se" });

    // add handler for the click event on the apply button
    $("#btn_adv_save2").click(applyConfig2);
	
		    // add resize handles to the textarea
    $("#adv_config_text3").resizable({ handles: "se" });

    // add handler for the click event on the apply button
    $("#btn_adv_save3").click(applyConfig3);

    
    // update the status/version information
    updateStatusL(true);
    
    // load the configuration
    loadConfig();
	
	    // load the configuration
    loadConfig1();
	
		    // load the configuration
    loadConfig2();
	
		    // load the configuration
    loadConfig3();

    // allow the loading dialog to close after all Ajax operation have finished
    $("#loadingDialog").ajaxStop(closeWaitingDialog);
   
});


